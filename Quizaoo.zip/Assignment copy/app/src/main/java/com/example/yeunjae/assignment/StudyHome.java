package com.example.yeunjae.assignment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;

public class StudyHome extends AppCompatActivity {

    //tagging activity for debugging purpose
    private static final String TAG = "StudyHome";

    //creating arraylist to put recyclerview pictures and names in
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private android.support.v7.widget.RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "Recycler View onCreate method started");

        //calling the names and images
        initImageBitmaps();
    }

    //adding image urls and names to arraylists into bitmaps
    private void initImageBitmaps() {

        //all pictures from flaticon.com

        mNames.add("View Course");
        mImageUrls.add("https://media.discordapp.net/attachments/490424238847557632/504664529490280458/201556.png");

        mNames.add("Highlight Text");
        mImageUrls.add("https://media.discordapp.net/attachments/490424238847557632/504664788761051147/1164693.png?width=427&height=427");

        mNames.add("Watch Videos");
        mImageUrls.add("https://media.discordapp.net/attachments/490424238847557632/504932690081087488/148744.png");

        Log.d(TAG, "initImageBitmaps: images and names added to arrayLists");

        //calling the recyclerview
        initRecylerView();

    }

    //making the recyclerview so it appears on the screen
    private void initRecylerView() {
        Log.d(TAG, "initRecylerView: initiated recycler view");
        recyclerView = findViewById(R.id.recycler_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames, mImageUrls);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //getting the position that user is clicking on so intents can be created

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {


                //the intents lead to the other activities based on where user clicked

                final Intent intent;
                switch (position) {
                    case 0:

                        intent = new Intent(StudyHome.this,FileViewer.class);
                        startActivity(intent);
                        Log.d(TAG, "onItemClick: first item in recyclerview is clicked. intent is started");
                        break;

                    case 1:

                        intent = new Intent(StudyHome.this,Highlighter.class);
                        startActivity(intent);
                        Log.d(TAG, "onItemClick: second item in recyclerview is clicked. intent is started");
                        break;

                    case 2:

                        intent = new Intent(StudyHome.this,YoutubeActivity.class);
                        startActivity(intent);
                        Log.d(TAG, "onItemClick: third item in recyclerview is clicked. intent is started");
                        break;

                    default:
                        intent = new Intent(StudyHome.this,FileViewer.class);
                        break;
                }
            }}));}


}





