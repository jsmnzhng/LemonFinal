package com.example.yeunjae.assignment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.xeoh.android.texthighlighter.TextHighlighter;

public class Highlighter extends AppCompatActivity {

    EditText highlightSearch;
    Button button;
    TextView titleSource2;
    TextView textSource2;

  //starts off as not highlighted
    boolean highlighted = false;

    TextHighlighter textHighlighter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_highlight);

        highlightSearch = (EditText)findViewById(R.id.highlightSearch);
        button = (Button)findViewById(R.id.button);
        textSource2 = (TextView)findViewById(R.id.textSource2);
        titleSource2 = (TextView)findViewById(R.id.titleSource2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            //starts a new highlight query
            public void onClick(View v) {
                if(!highlighted){
                    textHighlighter = new TextHighlighter();

                            //highlights the text based on input
                            //below uses information provided by https://github.com/xeoh/TextHighlighter
                            textHighlighter.setBackgroundColor(Color.parseColor("#ff8b61"))
                            .addTarget(titleSource2)
                            .addTarget(textSource2)
                            .highlight(highlightSearch.getText().toString(), TextHighlighter.CASE_INSENSITIVE_MATCHER);

                            //changes button so the user can stop the highlight
                            button.setText("Stop highlighting");
                }
                else {
                    //stops the highlight
                    textHighlighter.setBackgroundColor(Color.TRANSPARENT)
                            .invalidate(TextHighlighter.CASE_INSENSITIVE_MATCHER);

                    //changes button so user can start highlighting
                    button.setText("Enter");
                }

                highlighted = !highlighted;
            }
        });
    }
}
