package com.example.yeunjae.assignment;

import android.util.Log;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import static android.content.ContentValues.TAG;

public class Card {

    private static final String TAG = "Card";

    //Creating a flashcard

    private int _cardId;
    private String cardQuestion;
    private String cardAnswer;

    public Card() {
    }

    public Card(String cardQuestion, String cardAnswer) {
        this.cardQuestion = cardQuestion;
        this.cardAnswer = cardAnswer;
    }

    public String getCardQuestion() {
        return cardQuestion;
    }
    public void setCardQuestion(String cardQuestion) {
        this.cardQuestion = cardQuestion;
    }

    public String getCardAnswer() {
        return cardAnswer;
    }
    public void setCardAnswer(String cardAnswer) {
        this.cardAnswer = cardAnswer;
    }

    //Create default questions for flashcards
    public static Map<String,String> buildQuestions() {
        Map<String,String> questions = new LinkedHashMap<>();
        questions.put("What is the Lean Startup Methodology?","A methodology that focuses on developing sustainable business practices using minimal resources to encourage innovation and to deliver products and services to customers quicker.\n");
        questions.put("What is the key reason for start up failures?","They have an idea that people want, but fail to communicate with the public to incorporate their perspectives into the product. The Lean Startup Methodology attempts to solve this issue.\n");
        questions.put("What are the 5 lean start up principles?","1.\tEntrepreneurs are everywhere\n" +
                "2.\tEntrepreneurship is management\n" +
                "3.\tValidated Learning\n" +
                "4.\tInnovation Accounting\n" +
                "5.\tBuild – Measure - Learn\n");
        questions.put("q4","a4");
        questions.put("q5","a5");
        Log.d(TAG,"Questions added to array");

        return questions;
    }


}