package com.example.yeunjae.assignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import static android.content.ContentValues.TAG;

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "FlashCardDB";
    private static final String TABLE_CARD = "Cards";

    private static final String CARD_ID = "cardId";
    private static final String CARD_QUESTION = "cardQuestion";
    private static final String CARD_ANSWER = "cardAnswer";

    public DBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create table
        String query = "CREATE TABLE " + TABLE_CARD + "("
        + CARD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
        + CARD_QUESTION + " TEXT, "
        + CARD_ANSWER + " TEXT " + ");";

        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //drop means delete in sql --> will delete table
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARD);

        //create new table
        onCreate(db);

    }

    //Add new row to database
    public void addCard(Card cardNew){
        ContentValues values = new ContentValues();
        values.put(CARD_QUESTION, cardNew.getCardQuestion());
        values.put(CARD_ANSWER, cardNew.getCardAnswer());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE_CARD, null, values);

        Log.d(TAG, "DB Handler addCard: " + cardNew);

        db.close();

    }

    //Delete card from database
    public void deleteCard(int id){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM" + TABLE_CARD + "WHERE"+ CARD_ID+  "=" + id);

        Log.d(TAG, "deleteCard: " + id);
        db.close();
    }

//    //Print out db as String
//    public String databaseToString(){
//        String dbString = "";
//        SQLiteDatabase db = getWritableDatabase();
//        String query = "SELECT * FROM " + TABLE_CARD + " WHERE 1";
//
//        Cursor c = db.rawQuery(query,null);
//        c.moveToFirst();
//
//        while(!c.isAfterLast()){
//            if(c.getString(c.getColumnIndex("cardQuestion"+"cardAnswer"))!=null);{
//            dbString += c.getString(c.getColumnIndex("cardQuestion"+"cardAnswer"));
//            dbString+="\n";
//            }
//
//        }
//        db.close();
//        return dbString;
//    }

}


