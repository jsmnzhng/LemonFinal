package com.example.yeunjae.assignment;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Map;

public class EndActivity extends AppCompatActivity{

    private static final String TAG = "End Activity";


    private Button restartButton, studyButton;
    private TextView resultView, feedbackText, resultText, score;
    private ProgressBar progressBar;
    TestActivity test = new TestActivity();
    int i = test.getCounter();
    Map<String, String> ql = Card.buildQuestions();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);

        Intent intent = getIntent();
        int intValue = intent.getIntExtra("count", 0);
        double value = (double) intValue;
        double percent = ((value/ql.size())*100);
        int percentage = (int) percent;
        Resources res = getResources();
        Drawable drawable = res.getDrawable(R.drawable.circle_progress);


        //Progress bar that displays results
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(percentage);
        progressBar.setSecondaryProgress(100);
        progressBar.setMax(100);
        progressBar.setProgressDrawable(drawable);

        score = (TextView) findViewById(R.id.score);
        score.setText(percentage + "%");


        //Setting score results based on number of correct answers
        resultText = (TextView) findViewById(R.id.resultText);//       resultText2 = (TextView) findViewById(R.id.resultText2);
        resultView = (TextView) findViewById(R.id.resultView);

        resultText.setText("You got: ");
        resultView.setText("That's " + intValue + "/" + ql.size() + " correct");

        //displaying feedback message based on score percentage
        feedbackText = (TextView) findViewById(R.id.feedbackText);
        if (0<=percentage && percentage<=49){

           feedbackText.setText("You failed. Revise the study material and try again!");}

        else if (50<=percentage && percentage<=74){

           feedbackText.setText("You did alright, but you could do better. " +
                   "Read over the study notes again and make sure you understand the content." );}

        else if (75<=percentage && percentage<=90){

           feedbackText.setText("Good job! Revise the study material again to get" +
                   " 100% next time!");}

        else if (100==percentage ){

            feedbackText.setText("Well done, you got 100%! You should still go over the study material" +
                    " to make sure you understand everything.");}

        restartButton = (Button) findViewById(R.id.restartButton);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(EndActivity.this, TestActivity.class);
                startActivity(intent);
            }

    });

        studyButton = (Button) findViewById(R.id.studyButton);
        studyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(EndActivity.this, StudyHome.class);
                startActivity(intent);
            }

        });

        }}



