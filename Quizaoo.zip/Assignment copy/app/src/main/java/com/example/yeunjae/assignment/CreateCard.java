package com.example.yeunjae.assignment;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class CreateCard extends AppCompatActivity {

    private Button create;
    private Button delete;
    private TextView tv;
    private EditText question;
    private EditText answer;
    DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.card_create);

        question = (EditText) findViewById(R.id.questionText);
        answer = (EditText) findViewById(R.id.answerText);
        create = (Button) findViewById(R.id.createButton);
        tv = (TextView)findViewById(R.id.textView3);

//        delete = (Button) findViewById(R.id.deleteButton);
//        dbHandler = new DBHandler(this, null, null, 1);
//        printDatabase();}

    }
    public void insertQuestion(String s, String l){
//        create.setOnClickListener(new View.OnClickListener() {
//                                                  @Override
//            public void onClick(View v) {
//                String s = question.getText().toString();
//                String l = answer.getText().toString();
//              if(question.length() !=0 || answer.length() !=0){
//                  insertQuestion(s, l);
//              }
//                else {
//                  tv.setText("Text field cannot be empty");
//
//              }
//            }
//        });
    Card c = new Card(question.getText().toString(),answer.getText().toString() );
    dbHandler = new DBHandler(this, null, null, 1);
    dbHandler.addCard(c);
        Toast.makeText(this, "Card created", Toast.LENGTH_SHORT).show();
//    printDatabase();
    }
//
//
//    public void printDatabase(){
//        String s = dbHandler.databaseToString();
//        tv.setText(s);
//        answer.setText("");
//
//    }


    }